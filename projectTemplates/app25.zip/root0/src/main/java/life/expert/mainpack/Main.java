package life.expert.mainpack;









import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

//
//                          Vladimir Krupskiy (wilmer)
//                          app10 life.expert.mainpack
//                          12.02.18 22:26
// 
//
//  Naming convention:
//  *_isMethod	return bool
//  *_ref		return ref
//  *_should_	event handling: if possible handle
//  *_will_		event handling: will handle
//  *_did_		event handling: did handle
//
//  VC_		    class
//  VCG_        class generic
//  VV_         class non mutable value
//  VI_		    interface
//  VIL_        interface lambda
//  VA_		    annotation
//  VA_		    abstract class
//  VS_         static class
//  VE_		    enum
//  VX_         exception
//  VT_         thread
//  *_shared_	singleton
//
//  s_		    global or static
//  c_		    class poroperty
//  p_		    method parameter
//  f_		    class method
//  fg_         class method with generic argument or return
//  fl_         interface method lambda
//  v_		    variable
//  g_          generic type
//  l_          lambda variable
//  _inBlock	variables inside lambda
//
//




/**
 * class static (usual class with static properties and methods)
 * <pre>{@code
 *
 *
 * example 1
 *
 *              Main.fs_method();
 *
 *
 * example 2
 *
 *               (THIS not allowed)
 *
 *
 * example 4
 *
 *            No inheritance for static methods/properties (NO override)
 *
 *
 *
 * }</pre>
 */
//  public _package_ final                          
//  extends VS_                 implements VI_, VI_        
//  extends VSG_<String>        implements VIG_<String>       
public class Main
	{
	//////////////////////////////////////////////////////////////////////////////////
	//
	//                              static variables
	//
	//////////////////////////////////////////////////////////////////////////////////  
	/**
	 * log4j debug massage
	 * <pre>{@code
	 *
	 *
	 * example 1
	 *
	 *           log.debug   ( "app10 life.expert.mainpack Main:  " );
	 * 	        log.info    ( "app10 life.expert.mainpack Main:  " );
	 * 	        log.warn    ( "app10 life.expert.mainpack Main:  " );
	 * 	        log.error   ( "app10 life.expert.mainpack Main:  " );
	 *
	 *
	 * example 2
	 *
	 *
	 *
	 *
	 * }</pre>
	 */
	private static final Logger log = LogManager.getLogger( Main.class );
	
	/**
	 * static variable test
	 * <pre>{@code
	 *
	 *
	 * example 1
	 *
	 *           s_test  (THIS not allowed)
	 *
	 *
	 * example 2
	 *
	 *           static property not overrided
	 *
	 * }</pre>
	 */
	private static String s_test = new String( "test string" );
	
	
	//////////////////////////////////////////////////////////////////////////////////
	//
	//                              static constructors/initializers
	//
	//////////////////////////////////////////////////////////////////////////////////  
	
	
	
	
	/**                         static initializer default                       
	 * <pre>{@code
	 *
	 *
	 * exapmle 1
	 *
	 *           initializer called before methods
	 *
	 *
	 * example 2
	 *
	 *
	 *
	 * }</pre>
	 */
	static
		{
		//example
		//log.debug   ( "app10 life.expert.mainpack Main  INITIALIZER: " );
		s_test = "test";
		}
	
	/**
	 * PRIVATE constructor default: NO objects allowed
	 * otherwise java autogenerate PUBLIC default constructor
	 */
	//      throws Exception, VX_myxception   
	private Main( )
		{
		//super();  OR this("")
		//log.debug   ( "app10 life.expert.mainpack Main  NO PUBLIC CONSTRUCTOR ALLOWED: " );
			
		}
	
	//////////////////////////////////////////////////////////////////////////////////
	//
	//                              static methods
	//
	//////////////////////////////////////////////////////////////////////////////////  
	
	
	
	
	/**
	 * static method test
	 * <pre>{@code
	 *
	 *
	 * example 1
	 *
	 *           Main.fs_method();
	 *
	 *
	 * example 2
	 *
	 *           static method not overrided
	 *
	 *
	 * }</pre>
	 */
	//      public privateFinal _package_ 
	//      throws Exception, VX_myxception   
	public static void fs_method( )
		{
		//log.debug   ( "app10 life.expert.mainpack Main  g_method: " );
		//
		s_test = "test";
		//
		return;
		}
	
	
	
	
	/**
	 * STATIC method test with argument of ANYTYPE
	 * STATIC generic methods allowed
	 * <pre>{@code
	 *
	 *
	 * example 1
	 *
	 *           Main.f_testanyarg("stroka");
	 *           Main.f_testanyarg(12);
	 *
	 *
	 *
	 * example 2
	 *
	 *          static method not overrided
	 *
	 * }</pre>
	 */
	//      public privateFinal _package_
	//      throws Exception, VX_myxception 
	static public < g_1  /* extends super VC_ & VI_ */ /* extends super VCG_<?> & VIG_<?> */ /* extends super VCG_<g_1> & VIG_<g_1> */ /* extends super VCG_<String> & VIG_<String> */ > void fg_testanyarg( final g_1 p_1 )
		{
		//throw new VX_exception( "vError" );
		//super.fg_testanyarg(p_1);
		//log.debug( "argument type: " + (( p_1 instanceof VV_ ) ? "VV_" : "no") );
		//log.debug( "\$  f_testanyarg: "+p_1 );
		//!NO new g_1()
		
		
		//
		return;
		}




	/**
	 * main class
	 * <pre>{@code
	 *
	 *
	 *      1) создадим новый проект
	 *               в настройках IDEA select code style = выберем мою схему
	 *
	 *      4) добавим пакеты life.expert.mainpack и класс VV_main
	 *
	 *       2) добавим поддержку мевена
	 *               клик на project -> add framework support = maven
	 *              ОБЯЗАТЕЛЬНО НАЖАТЬ В ПРАВОМ НИЖНЕМ УГЛУ В ВЫСКОЧИВШЕМ ОКНЕ enable auto import
	 *              помести внутрь тегов в помке снипет maven
	 *
	 * 7) добавим файл src/main/java/resources/log4j2.xml
	 *
	 *       3) добавим metainf
	 *               cmd+; -> artifacts -> jar -> from modules -> директорию выберем resources
	 *               (или перетащить мышкой meta-inf в подпапку resources
	 *
	 *       5) создать конфигурацию "Application" для запуска
	 *               выбрать главный класс для запуска
	 *
	 *      6) проверим: сбилдим цель и провери мавенBUILD
	 *
	 *
	 *
	 * }</pre> ПОМНИ СГЕНЕРИТЬ JAVADOC MAC8+fixDocComment И УБРАТЬ ЭТОТ ТЕКСТ
	 */



	public static void main( final String... p_i )
		{
		//System.out.println( "VV_main main " );
		log.info( "_________start_programm_________________________" );
		
		
		var s = List.of( "a", "b", "c" );
		List< String > strings = List.copyOf( s );
		strings.forEach( System.out::println );
		
		
		
		
		}

		
	}
