//@Header@
//--------------------------------------------------------------------------------
//
//--------------------------------------------------------------------------------
//  app25
//
//  Copyright 2018 Wilmer Krisp
//  Licensed under the Apache License, Version 2.0
//
//  Author: wilmer
//  Created: 2018/08/16
//

module app25
	{
	exports ${IJ_BASE_PACKAGE};
	opens ${IJ_BASE_PACKAGE};
 
	
	
	
	
	requires org.mockito;
	//requires truth;
	requires flogger;
	//requires truth.java8.extension;
	
	
	requires auto.value.annotations;
	requires com.google.common;
	requires org.apache.commons.lang3;
	
	
	requires gson;
	requires java.sql;
	
	requires org.jetbrains.annotations;
	
	
	
	
	
 
	
	//requires commons.pool2;
	requires com.github.benmanes.caffeine;
	requires jdk.unsupported;
	
	
	
	
	}

