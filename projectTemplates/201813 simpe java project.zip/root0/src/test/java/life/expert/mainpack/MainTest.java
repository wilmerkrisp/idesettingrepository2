package ${IJ_BASE_PACKAGE};








import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static com.google.common.truth.Truth.*;


import static org.junit.jupiter.api.Assertions.*;
//
//                          Vladimir Krupskiy (wilmer)
//                          app10 ${IJ_BASE_PACKAGE}
//                          12.02.18 22:27
//
//
//  Naming convention:
//  *_isMethod	return bool
//  *_ref		return ref
//  *_should_	event handling: if possible handle
//  *_will_		event handling: will handle
//  *_did_		event handling: did handle
//
//  VC_		    class
//  VCG_        class generic
//  VV_         class non mutable value
//  VI_		    interface
//  VIL_        interface lambda
//  VA_		    annotation
//  VA_		    abstract class
//  VS_         static class
//  VE_		    enum
//  VX_         exception
//  VT_         thread
//  *_shared_	singleton
//
//  s_		    global or static
//  c_		    class poroperty
//  p_		    method parameter
//  f_		    class method
//  fg_         class method with generic argument or return
//  fl_         interface method lambda
//  v_		    variable
//  g_          generic type
//  l_          lambda variable
//  _inBlock	variables inside lambda
//
//




class MainTest
	{
	
	@BeforeEach
	void setUp( )
		{
		}
	
	
	
	
	@Test
	void fs_method( )
		{
		assertThat( "none" ).startsWith( "none" );
		}
	
	
	
	
	@Test
	void fg_testanyarg( )
		{
		}
	
	
	
	
	@Test
	void main( )
		{
		}
	}