package ${IJ_BASE_PACKAGE};//@Header@
//--------------------------------------------------------------------------------
//
//                          graph  ${IJ_BASE_PACKAGE}
//                           wilmer 2019/01/23
//
//--------------------------------------------------------------------------------









import com.google.common.flogger.FluentLogger;

import java.util.ResourceBundle;
import java.util.logging.LogManager;
import java.util.logging.Logger;









public class App
	{
	
	
	private static final FluentLogger logger_ = FluentLogger.forEnclosingClass();
	
	
	
	private static final ResourceBundle bundle_ = ResourceBundle.getBundle( "messages" );
	
	
	
	private static final String START_MESSAGE_ = bundle_.getString( "startProgram" );
	
	/**
	 * main class
	 * !CHANGE_ME_DESCRIPTION!
	 *
	 * <pre>{@code
	 *
	 *      0) изменим gradle->use gradle wrapper task configuration
	 *
	 *      0) ./gradlew wrapper --gradle-version=5.1.1
	 *
	 *      1) создадим новый проект
	 *               в настройках IDEA select code style = выберем мою схему
	 *
	 *      4) добавим пакеты life.expert.mainpack и класс VV_main
	 *
	 *       2) добавим поддержку мевена
	 *               клик на project -> add framework support = maven
	 *              ОБЯЗАТЕЛЬНО НАЖАТЬ В ПРАВОМ НИЖНЕМ УГЛУ В ВЫСКОЧИВШЕМ ОКНЕ enable auto import
	 *              помести внутрь тегов в помке снипет maven
	 *
	 * 7) добавим файл src/main/java/resources/log4j2.xml
	 *
	 *       3) добавим metainf
	 *               cmd+; -> artifacts -> jar -> from modules -> директорию выберем resources
	 *               (или перетащить мышкой meta-inf в подпапку resources
	 *
	 *       5) создать конфигурацию "Application" для запуска
	 *               выбрать главный класс для запуска
	 *
	 *      6) проверим: сбилдим цель и провери мавенBUILD
	 *
	 *
	 *
	 * }</pre> ПОМНИ СГЕНЕРИТЬ JAVADOC MAC8+fixDocComment И УБРАТЬ ЭТОТ ТЕКСТ
	 */
	
	
	
	public static void main( final String... p_i )
		{
		//System.out.println( "VV_main main " );
		logger_.atInfo().log( START_MESSAGE_ );
		
		
		}
		
		
		
	}
