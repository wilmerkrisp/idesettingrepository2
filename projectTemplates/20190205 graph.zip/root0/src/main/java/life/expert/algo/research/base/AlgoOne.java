package ${IJ_BASE_PACKAGE};//@Header@
//--------------------------------------------------------------------------------
//
//                          graph  ${IJ_BASE_PACKAGE}
//                           wilmer 2019/02/04
//
//--------------------------------------------------------------------------------









import com.google.common.flogger.FluentLogger;









public class AlgoOne
	{
	
	private static final FluentLogger logger_ = FluentLogger.forEnclosingClass();
	
	private AlgoOne()
		{
		
		}
	
	
	
	public static AlgoOne of()
		{
		return new AlgoOne();
		}
	
	
	
	public void run()
		{
		
		try
			{
			Thread.sleep( 100 );
			}
		catch(final InterruptedException p_exception )
			{
			logger_.atSevere().log("Sleep interrupted");
			}
		
		
		return;
		}
		
		
	}
