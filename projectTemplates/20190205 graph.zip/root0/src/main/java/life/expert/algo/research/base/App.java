package ${IJ_BASE_PACKAGE};//@Header@
//--------------------------------------------------------------------------------
//
//                          graph  ${IJ_BASE_PACKAGE}
//                           wilmer 2019/01/23
//
//--------------------------------------------------------------------------------









import com.google.common.flogger.FluentLogger;
import static life.expert.common.io.FileUtils.*;

import java.io.InputStream;
import java.util.ResourceBundle;
import java.util.logging.LogManager;
import java.util.logging.Logger;









/**
 * The type App.
 */
public class App
	{
	
	
	
	private static final FluentLogger logger_ = FluentLogger.forEnclosingClass();
	
	
	
	private static final ResourceBundle bundle_ = ResourceBundle.getBundle( "messages" );
	
	
	
	private static final String START_MESSAGE_ = bundle_.getString( "startProgram" );
	
	
	
	static
		{
		InputStream stream = App.class.getClassLoader()
		                              .getResourceAsStream( "logging.properties" );
		
		ioWrapper( () -> LogManager.getLogManager()
		                                      .readConfiguration( stream ) , "No src/main/resources/logging.properties!" );
		}
	
	
	
	/**
	 * *    - пакет задать ${IJ_BASE_PACKAGE}
	 * *
	 * *    - change   rootProject.name  in settings.gradle
	 *                 project name in project settings
	 * *
	 * *
	 * *    - изменим gradle->use gradle wrapper task configuration
	 * *
	 * *    - ./gradlew wrapper --gradle-version=5.2
	 * *
	 * *    - app run config, vm options
	 * *            -javaagent:/Users/wilmer/.flow/resources/javaagent.jar -Dflow.agent.autostart -Dflow.agent.include=life.expert.algo
	 * *
	 * *
	 * *    - создадим новый проект
	 * *               в настройках IDEA select code style = выберем мою схему
	 * *
	 * *    - добавим пакеты life.expert.mainpack и класс VV_main
	 * *
	 * *    - добавим поддержку мевена
	 * *               клик на project -> add framework support = maven
	 * *              ОБЯЗАТЕЛЬНО НАЖАТЬ В ПРАВОМ НИЖНЕМ УГЛУ В ВЫСКОЧИВШЕМ ОКНЕ enable auto import
	 * *              помести внутрь тегов в помке снипет maven
	 * *
	 * *    - добавим файл src/main/java/resources/log4j2.xml
	 * *
	 * *    - добавим metainf
	 * *               cmd+; -> artifacts -> jar -> from modules -> директорию выберем resources
	 * *               (или перетащить мышкой meta-inf в подпапку resources
	 * *
	 * *    - создать конфигурацию "Application" для запуска
	 * *               выбрать главный класс для запуска
	 * *
	 * *    - проверим: сбилдим цель и провери мавенBUILD
	 * *
	 * *
	 * @param p_i
	 * 	the p i
	 */
	public static void main( final String... p_i )
		{
		//System.out.println( "VV_main main " );
		logger_.atInfo()
		       .log( START_MESSAGE_ );
		
		
		AlgoOne a = AlgoOne.of();
		a.run();
		
		}
		
		
		
	}
