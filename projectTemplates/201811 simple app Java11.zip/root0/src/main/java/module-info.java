//@Header@
//--------------------------------------------------------------------------------
//                              
//--------------------------------------------------------------------------------
//  app25 
//
//  Copyright 2018 Wilmer Krisp
//  Licensed under the Apache License, Version 2.0
//
//  Author: wilmer
//  Created: 2018/08/16
// 

module app25
	{
	exports ${IJ_BASE_PACKAGE};
	opens ${IJ_BASE_PACKAGE};
 
	requires org.apache.logging.log4j;
	requires org.apache.logging.log4j.core;
	
	requires org.apache.commons.lang3;
	
	requires org.mockito;
	requires org.checkerframework.checker.qual;
	
	
	
	
	
	requires commons.pool2;
	requires auto.value.annotations;
	requires com.google.common;
	}

