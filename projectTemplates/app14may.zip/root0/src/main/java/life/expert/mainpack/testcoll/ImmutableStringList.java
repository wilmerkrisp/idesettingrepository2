package life.expert.mainpack;









import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableCollection;
import com.google.common.collect.ImmutableList;
import org.apache.commons.lang3.SerializationUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.io.Serializable;
import java.util.Comparator;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;

//import java.util.*;


//@Header@
//--------------------------------------------------------------------------------
//                              life.expert.mainpack
//--------------------------------------------------------------------------------
//  app13 
//
//  Copyright 2018 Wilmer Krisp
//  Licensed under the Apache License, Version 2.0
//
//  Author: wilmer
//  Created: 2018/03/31
// 



//////////////////////////////////////////////////////////////////////////////////
//  class                              
//////////////////////////////////////////////////////////////////////////////////
//<editor-fold desc="class mutable">
/*


*               VC_somesubclass             extends ImmutableStringList implements VI_, VI_
*               VC_somesubclass< T >    extends ImmutableStringList implements VI_, VI_



1) please use new-call pattern  (construcor/method with params  instead setters)
    - check integrity of object inside constructors

2) cloning ( prop = new PropClass(prop) ) ALL MUTABLE props in constructor with params
    or use only immutable props



extends VC_             implements VI_, VI_                                           
extends VCG_<String>    implements VIG_<String>
public class ImmutableStringList< T >     extends VCG_< T >   implements VIG_< T >                                                                                      
@Override @Deprecated
public _package_ final
*/
//</editor-fold>









/**
 * class
 * my IMmutable list
 * <p>
 * Make class simple without generic:
 * 1) reformat code
 * 5) replace all String with Type1       (click MATCH CASE)
 *
 * <pre>{@code
 *
 * example 1
 *
 *   ImmutableStringList v_obj = new ImmutableStringList();
 *   v_obj.oneCompute();
 *
 * example 2
 *
 * ImmutableStringList v2 = new ImmutableStringList("one","two","th3");
 *
 * example 3
 *
 * ImmutableStringList v2 = new ImmutableStringList(coll);
 *
 * example 4
 * ImmutableStringList v2 =  ImmutableStringList.of("one","two","th3");
 *
 * example 5
 * ImmutableStringList v2 =  ImmutableStringList.of(coll);
 *
 *
 * }</pre>
 */
public class ImmutableStringList
	extends ArrayList< String >
	implements Serializable
	{
	
	
	
	//<editor-fold desc="log4j">
	/*
	Вывод сообщений логов log4j
	log_.debug   ( "msg" );     use for default
	log_.info    ( "msg" );
	log_.warn    ( "msg" );
	log_.error   ( "msg" );
	*/
	//</editor-fold>	
	
	
	
	private static final Logger log_ = LogManager.getLogger( ImmutableStringList.class );
	
	
	
	private static final UnsupportedOperationException exception_()
		{
		return new UnsupportedOperationException( "The collection is immutable. Don't use CrUD methods." );
		}
	
	
	//////////////////////////////////////////////////////////////////////////////////
	//  additional methods
	//////////////////////////////////////////////////////////////////////////////////
	
	
	
	/**
	 * Returns flag that the class is read only.
	 *
	 * @return Returns flag that the class is read only.
	 */
	public boolean isReadOnly()
		{
		return true;
		}
	
	
	//<editor-fold desc="empty instance singleton">
	/*
    1) ! замечаение для мутабельных классов: пожалуйста переделайте так чтобы переменная возвращала немутабельную версию класса
    2) ! пожалуйста укажите корректные пустые значения свойств
	*/
	//</editor-fold>	
	
	
	
	private static final ImmutableStringList emptyInstance = new ImmutableStringList();
	
	
	
	/**
	 * fabric  = empty object
	 *
	 *
	 * <pre>{@code
	 *
	 * exapmle 1
	 *
	 *           ImmutableStringList v_obj2 =  ImmutableStringList.getEmptyInstance();
	 *
	 * }</pre>
	 *
	 * @param
	 *
	 * @return
	 */
	public static ImmutableStringList getEmptyInstance()
		{
		return emptyInstance;
		}
	
	
	//////////////////////////////////////////////////////////////////////////////////
	//  classic constructors and fabric
	//////////////////////////////////////////////////////////////////////////////////
	
	
	
	/**
	 * constructor default
	 * <p>
	 * it's no use, because you cant add elements after
	 *
	 * <pre>{@code
	 *
	 * exapmle 1
	 *
	 *           ImmutableStringList v_obj = new ImmutableStringList();
	 *
	 *
	 * }</pre>
	 */
	public ImmutableStringList()
		{
		super();
		}
	
	
	
	/**
	 * constructor with capacity
	 * Analogically to usual collections
	 * <p>
	 * it's no use, because you cant add elements after
	 *
	 * <pre>{@code
	 *
	 * exapmle 1
	 *
	 *           ImmutableStringList v_obj = new ImmutableStringList(12);
	 *
	 *
	 * }</pre>
	 */
	public ImmutableStringList( int initialCapacity )
		{
		super( initialCapacity );
		}
	
	
	
	/**
	 * constructor with parameter(collection)
	 * Analogically to usual collections
	 * <p>
	 * (!) uses ADD method of SUPER class
	 * (!) DEEP copying of IMMUTABLE-property-objects in constructor
	 *
	 * <pre>{@code
	 *
	 * exapmle 1
	 *
	 *           ImmutableStringList v_obj = new ImmutableStringList(someCollection);
	 *
	 *
	 * }</pre>
	 */
	public ImmutableStringList( Collection< ? extends String > collection )
		{
		super( Objects.requireNonNull( collection ) );
		}
	
	
	//<editor-fold desc="check inconsistency in constructor of immutable object">
/*  

ПАТТЕРН NEW-CALL В неМУТАБЕЛЬНЫХ КЛАССАХ:

- следует проектировать типы так чтобы объекты не могли существовать в недопустимом состоянии
    - поэтому следует проверять консистентность объекта в конструкторе и вызывать IllegalStateException 

- в конструкторе сразу задаются все параметры требуемые для настройки объекта
  - настройки не могут быть изменены после инициализации в конструкторе
            
- throw new IllegalStateException( item1+item2 ); 

*/
	//</editor-fold>
	
	
	
	/**
	 * fabric with vararg
	 * Analogically to List.of
	 * <p>
	 * (!) uses ADD method of SUPER class
	 * (!) SHALLOW COPYING OF OBJECT IN CONSTRUCTOR
	 *
	 * <pre>{@code
	 *
	 * exapmle 1
	 *
	 *           ImmutableStringList v_obj =  ImmutableStringList.of("one","two","th3");
	 *
	 *
	 * }</pre>
	 */
	public static ImmutableStringList of( String... elements )
		{
		//		super( elements.length );
		//		for( String element : elements )
		//			{
		//			/* super. is necessary because we should not call overrided methods in constructor*/
		//			super.add( Objects.requireNonNull( element ) );
		//			}
		
		Objects.requireNonNull( elements );
		return new ImmutableStringList( List.of( elements ) );
		}
	
	
	
	/**
	 * fabric with parameter(collection)
	 * Analogically to usual collections
	 * <p>
	 * (!) DEEP copying of IMMUTABLE-property-objects in constructor
	 *
	 * <pre>{@code
	 *
	 * exapmle 1
	 *
	 *           ImmutableStringList v_obj =  ImmutableStringList.newList(someCollection);
	 *
	 *
	 * }</pre>
	 */
	public static ImmutableStringList copyOf( Collection< ? extends String > collection )
		{
		Objects.requireNonNull( collection );
		return new ImmutableStringList( collection );
		}
	
	
	
	public static < E extends Collection< ? extends String > & Serializable > ImmutableStringList DeepCopyOf( E collection )
		{
		Objects.requireNonNull( collection );
		return copyOf( (E) SerializationUtils.clone( collection ) );
		}
	
	//////////////////////////////////////////////////////////////////////////////////
	//  additional fabrics
	//////////////////////////////////////////////////////////////////////////////////
	
	
	
	public static ImmutableStringList copyOf( Iterable< ? extends String > elements )
		{
		Objects.requireNonNull( elements );
		return elements instanceof Collection ? copyOf( (Collection) elements ) : copyOf( elements.iterator() );
		}
	
	
	
	public static < E extends Iterable< ? extends String > & Serializable > ImmutableStringList DeepCopyOf( E elements )
		{
		Objects.requireNonNull( elements );
		return copyOf( (E) SerializationUtils.clone( elements ) );
		}
	
	
	
	private ImmutableStringList( Iterator< ? extends String > elements )
		{
		this();
		while( elements.hasNext() )
			{
			super.add( elements.next() );
			}
		}
	
	
	
	public static ImmutableStringList copyOf( Iterator< ? extends String > elements )
		{
		Objects.requireNonNull( elements );
		return new ImmutableStringList( elements );
		}
	
	
	
	public static < E extends Iterator< ? extends String > & Serializable > ImmutableStringList DeepCopyOf( E elements )
		{
		Objects.requireNonNull( elements );
		return copyOf( (E) SerializationUtils.clone( elements ) );
		}
	
	
	//////////////////////////////////////////////////////////////////////////////////
	//  override methods for immutability
	//////////////////////////////////////////////////////////////////////////////////
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public boolean add( String e )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public boolean addAll( Collection< ? extends String > c )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public boolean addAll( int index ,
	                             Collection< ? extends String > c )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public void clear()
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public boolean remove( Object o )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public boolean removeAll( Collection< ? > c )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public boolean removeIf( Predicate< ? super String > filter )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public void replaceAll( UnaryOperator< String > operator )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public boolean retainAll( Collection< ? > c )
		{
		throw exception_();
		}
	
	
	
	/**
	 * unsupported for immutable
	 */
	@Override
	@Deprecated
	final public void sort( Comparator< ? super String > c )
		{
		throw exception_();
		}
	
	
	
	//////////////////////////////////////////////////////////////////////////////////
	//  implementations                              
	//////////////////////////////////////////////////////////////////////////////////
	//<editor-fold desc="implementations">
    /*
    
    (1) Base class AbstractList already has a good implementation of
        - EQUALS,
        - HASHCODE,
        - shallow CLONE
    
    (2) Do not use default clone, use copy deep constructor and fabric
    

    */
	//</editor-fold>
	
	
	
	/**
	 * classic overrided method
	 * toString
	 *
	 * <pre>{@code
	 *
	 *
	 * }</pre>
	 */
	@Override
	public String toString()
		{
		String addr = Integer.toHexString( System.identityHashCode( this ) );
		return "ImmutableStringList@" + addr + " " + super.toString();
		}
	
	//////////////////////////////////////////////////////////////////////////////////
	//  add your own methods                              
	//////////////////////////////////////////////////////////////////////////////////
	
	
	
	//<editor-fold desc="some method">
    /* 
    
    public privateFinal protectedPackage _package_ final
    throws Exception, VX_myxception
    @Override
    */
	//</editor-fold>
	
	
	
	/**
	 * method f_method
	 * <p>
	 * <p>
	 * !CHANGE_ME_DESCRIPTION!
	 *
	 * <pre>{@code
	 *
	 *
	 * example 1
	 *            - генерирую runtime ошибки программирования
	 *            - генерирую runtime ошибки выполнения метода, если метод не вернет то что должен
	 *
	 *
	 * example 2
	 *
	 *           v_obj.f_method("test");
	 *
	 * example 3
	 *
	 *           - covariance: this overrided method can return subclass unstead class:
	 *                  resultSomeSuperclass f_method()
	 *                  resultSomeSubclass   f_overrided_method()
	 *
	 *
	 * }</pre> ПОМНИ СГЕНЕРИТЬ JAVADOC MAC8+fixDocComment И УБРАТЬ ЭТОТ ТЕКСТ
	 */
	public void compute( final String p_1 )
		{
		//<editor-fold desc="additionally">
        /* 
        
        log_.debug( "MyList f_method: " + p_1 );
        super.f_method(p_1);
        
        */
		//</editor-fold>
		
		
		return;
		}
		
		
	}
