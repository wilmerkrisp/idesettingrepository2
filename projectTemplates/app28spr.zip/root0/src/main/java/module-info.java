//@Header@
//--------------------------------------------------------------------------------
//                              
//--------------------------------------------------------------------------------
//  app25 
//
//  Copyright 2018 Wilmer Krisp
//  Licensed under the Apache License, Version 2.0
//
//  Author: wilmer
//  Created: 2018/08/16
// 

module app25
	{
	exports ${IJ_BASE_PACKAGE};
	opens ${IJ_BASE_PACKAGE};
	
	requires org.apache.logging.log4j;
	requires org.apache.logging.log4j.core;
	
	//requires org.apache.commons.configuration2;
	requires org.apache.commons.lang3;
	//requires org.apache.commons.text;
	
	requires org.mockito;
	
	
	
	requires java.sql;
	requires spring.context;
	requires spring.boot.autoconfigure;
	requires spring.boot;
	
	requires spring.web;
	requires spring.beans;
	requires checker.qual;
	}

