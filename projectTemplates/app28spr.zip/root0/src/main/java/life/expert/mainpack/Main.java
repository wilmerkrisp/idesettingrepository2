package ${IJ_BASE_PACKAGE};







import org.checkerframework.checker.nullness.qual.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

//
//                          Vladimir Krupskiy (wilmer)
//                          app10 ${IJ_BASE_PACKAGE}
//                          12.02.18 22:26
// 
//
//  Naming convention:
//  *_isMethod	return bool
//  *_ref		return ref
//  *_should_	event handling: if possible handle
//  *_will_		event handling: will handle
//  *_did_		event handling: did handle
//
//  VC_		    class
//  VCG_        class generic
//  VV_         class non mutable value
//  VI_		    interface
//  VIL_        interface lambda
//  VA_		    annotation
//  VA_		    abstract class
//  VS_         static class
//  VE_		    enum
//  VX_         exception
//  VT_         thread
//  *_shared_	singleton
//
//  s_		    global or static
//  c_		    class poroperty
//  p_		    method parameter
//  f_		    class method
//  fg_         class method with generic argument or return
//  fl_         interface method lambda
//  v_		    variable
//  g_          generic type
//  l_          lambda variable
//  _inBlock	variables inside lambda
//
//




/**
 * class static (usual class with static properties and methods)
 * <pre>{@code
 *
 *
 * example 1
 *
 *              Main.fs_method();
 *
 *
 * example 2
 *
 *               (THIS not allowed)
 *
 *
 * example 4
 *
 *            No inheritance for static methods/properties (NO override)
 *
 *
 *
 * }</pre>
 */
@SpringBootApplication
public class Main
	{
 
	/**
	 * log4j debug massage
	 * <pre>{@code
	 *
	 *
	 * example 1
	 *
	 *           log.debug   ( "app10 ${IJ_BASE_PACKAGE} Main:  " );
	 * 	        log.info    ( "app10 ${IJ_BASE_PACKAGE} Main:  " );
	 * 	        log.warn    ( "app10 ${IJ_BASE_PACKAGE} Main:  " );
	 * 	        log.error   ( "app10 ${IJ_BASE_PACKAGE} Main:  " );
	 *
	 *
	 * example 2
	 *
	 *
	 *
	 *
	 * }</pre>
	 */
	private static final Logger log = LogManager.getLogger( Main.class );
	
 

	/**
	 * main class
	 * <pre>{@code
	 *
	 *
	 *      1) создадим новый проект
	 *               в настройках IDEA select code style = выберем мою схему
	 *
	 *      4) добавим пакеты ${IJ_BASE_PACKAGE} и класс VV_main
	 *
	 *       2) добавим поддержку мевена
	 *               клик на project -> add framework support = maven
	 *              ОБЯЗАТЕЛЬНО НАЖАТЬ В ПРАВОМ НИЖНЕМ УГЛУ В ВЫСКОЧИВШЕМ ОКНЕ enable auto import
	 *              помести внутрь тегов в помке снипет maven
	 *
	 * 7) добавим файл src/main/java/resources/log4j2.xml
	 *
	 *       3) добавим metainf
	 *               cmd+; -> artifacts -> jar -> from modules -> директорию выберем resources
	 *               (или перетащить мышкой meta-inf в подпапку resources
	 *
	 *       5) создать конфигурацию "Application" для запуска
	 *               выбрать главный класс для запуска
	 *
	 *      6) проверим: сбилдим цель и провери мавенBUILD
	 *
	 *
	 *
	 * }</pre> ПОМНИ СГЕНЕРИТЬ JAVADOC MAC8+fixDocComment И УБРАТЬ ЭТОТ ТЕКСТ
	 */



	public static void main( final String... p_i )
		{
		//System.out.println( "VV_main main " );
		log.info( "_________start_programm_________________________" );
		
		
		var s = List.of( "a", "b", "c" );
		List< String > strings = List.copyOf( s );
		strings.forEach( System.out::println );
		
		
		SpringApplication.run( Main.class ,  p_i );
		
		
		}

		
	}
